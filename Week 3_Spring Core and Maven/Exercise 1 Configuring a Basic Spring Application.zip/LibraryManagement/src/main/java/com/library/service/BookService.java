package com.library.service;

public class BookService {
    public void addBook(String title) {
        System.out.println("Adding book: " + title);
    }
}

